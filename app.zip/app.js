var left = 0;
function abc(){
    console.log(event.keycode)
    var character = document.getElementById("character")
    if(event.keyCode === 68 && left < 1200){
        left = left + 10
        character.style.left = left + "px"
        character.src = 'IMAGES/spider1.gif'
    }
    if(event.keyCode === 65 && left > 0 ){
        left = left - 10
        character.style.left = left + "px"
        character.src = 'IMAGES/spider1.gif'
    }
    if(event.keyCode === 32 ){
        character.style.width = 300 + 'px'
        character.style.height = 300 + 'px'
        character.src = 'IMAGES/spider2.gif'
        setTimeout(function foo() {
          character.src = 'IMAGES/spider1.gif'
          character.style.width = '400px'
          character.style.height = '200px'

        },3000)
    }
}
window.onkeydown = abc